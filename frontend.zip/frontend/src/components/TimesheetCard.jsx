/**
 * TimesheetCard – Khu Bảng công trên Trang chủ.
 *
 * Gồm: biểu đồ vành khuyên SVG thuần, chú thích 5 loại ngày,
 * và hàng thẻ ngày nhỏ cuộn ngang.
 *
 * Biểu đồ vẽ bằng SVG (không dùng thư viện) theo yêu cầu.
 * Phần này của đồng nghiệp, chỉ cần khung đúng + dữ liệu mẫu.
 */
// TODO: nối API bảng công
import { useRef, useMemo } from 'react';
import { Card, Typography, Button } from 'antd';
import { RightOutlined } from '@ant-design/icons';
import { countWorkingDays, getWorkingDaysInMonth } from '../utils/dates';
import { buildMockTimesheet, countByStatus, STATUS_CONFIG } from '../data/mockTimesheet';

const { Text, Title } = Typography;

/** Vẽ một cung tròn SVG (arc) cho biểu đồ vành khuyên */
function describeArc(cx, cy, r, startAngle, endAngle) {
  const rad = (angle) => ((angle - 90) * Math.PI) / 180;
  const x1 = cx + r * Math.cos(rad(startAngle));
  const y1 = cy + r * Math.sin(rad(startAngle));
  const x2 = cx + r * Math.cos(rad(endAngle));
  const y2 = cy + r * Math.sin(rad(endAngle));
  const largeArc = endAngle - startAngle > 180 ? 1 : 0;
  return `M ${x1} ${y1} A ${r} ${r} 0 ${largeArc} 1 ${x2} ${y2}`;
}

function DonutChart({ counts, total }) {
  const cx = 70, cy = 70, r = 55, strokeWidth = 18;

  // Thứ tự vẽ các phần
  const segments = [
    { key: 'full', count: counts.full },
    { key: 'leave', count: counts.leave },
    { key: 'partial', count: counts.partial },
    { key: 'absent', count: counts.absent },
    { key: 'pending', count: counts.pending },
  ];

  const worked = total - counts.pending;
  let currentAngle = 0;

  return (
    <svg width={140} height={140} viewBox="0 0 140 140">
      {/* Nền tròn xám nhạt */}
      <circle cx={cx} cy={cy} r={r} fill="none" stroke="#f0f0f0" strokeWidth={strokeWidth} />

      {segments.map((seg) => {
        if (seg.count === 0 || total === 0) return null;
        const angle = (seg.count / total) * 360;
        // Tránh vẽ arc 360 độ (lỗi SVG), dùng 359.99
        const endAngle = currentAngle + Math.min(angle, 359.99);
        const color = STATUS_CONFIG[seg.key].color;
        const path = describeArc(cx, cy, r, currentAngle, endAngle);
        currentAngle += angle;

        return (
          <path
            key={seg.key}
            d={path}
            fill="none"
            stroke={seg.key === 'pending' ? '#e8e8e8' : color}
            strokeWidth={strokeWidth}
            strokeLinecap="butt"
          />
        );
      })}

      {/* Chữ giữa */}
      <text x={cx} y={cy - 8} textAnchor="middle" fontSize={12} fill="#999">
        Tổng
      </text>
      <text x={cx} y={cy + 12} textAnchor="middle" fontSize={14} fontWeight="bold" fill="#333">
        {worked}/{total} ngày
      </text>
    </svg>
  );
}

function TimesheetCard() {
  const scrollRef = useRef(null);

  const now = new Date();
  const year = now.getFullYear();
  const month = now.getMonth();

  const totalWorkingDays = useMemo(() => countWorkingDays(year, month), [year, month]);
  const workingDays = useMemo(() => getWorkingDaysInMonth(year, month), [year, month]);
  const timesheetData = useMemo(() => buildMockTimesheet(workingDays), [workingDays]);
  const counts = useMemo(() => countByStatus(timesheetData), [timesheetData]);

  // Cuộn sang phải khi bấm mũi tên
  function handleScroll() {
    scrollRef.current?.scrollBy({ left: 200, behavior: 'smooth' });
  }

  // 5 dòng chú thích
  const legendItems = [
    { key: 'pending', ...STATUS_CONFIG.pending },
    { key: 'full', ...STATUS_CONFIG.full },
    { key: 'leave', ...STATUS_CONFIG.leave },
    { key: 'partial', ...STATUS_CONFIG.partial },
    { key: 'absent', ...STATUS_CONFIG.absent },
  ];

  return (
    <Card style={{ height: '100%' }} styles={{ body: { padding: 16 } }}>
      <div style={{ display: 'flex', alignItems: 'flex-start', gap: 16 }}>
        {/* Tiêu đề + biểu đồ */}
        <div style={{ textAlign: 'center' }}>
          <Title level={5} style={{ marginBottom: 8 }}>Bảng công</Title>
          <DonutChart counts={counts} total={totalWorkingDays} />
        </div>

        {/* Chú thích 5 dòng */}
        <div style={{ flex: 1, paddingTop: 24 }}>
          {legendItems.map((item) => (
            <div key={item.key} style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
              <span
                style={{
                  display: 'inline-block',
                  width: 14,
                  height: 14,
                  borderRadius: 3,
                  background: item.color,
                  border: item.borderColor ? `2px solid ${item.borderColor}` : '1px solid #d9d9d9',
                  flexShrink: 0,
                }}
              />
              <Text style={{ fontSize: 12 }}>{item.label}</Text>
            </div>
          ))}
        </div>
      </div>

      {/* Hàng thẻ ngày nhỏ, cuộn ngang */}
      <div style={{ display: 'flex', alignItems: 'center', marginTop: 12, gap: 8 }}>
        <div
          ref={scrollRef}
          style={{
            display: 'flex',
            gap: 6,
            overflowX: 'auto',
            flex: 1,
            paddingBottom: 4,
            scrollbarWidth: 'thin',
          }}
        >
          {timesheetData.map((d, i) => {
            const cfg = STATUS_CONFIG[d.status];
            return (
              <div
                key={i}
                style={{
                  minWidth: 64,
                  padding: '4px 6px',
                  borderRadius: 6,
                  textAlign: 'center',
                  fontSize: 11,
                  fontWeight: 500,
                  background: cfg.color,
                  border: cfg.borderColor ? `1px solid ${cfg.borderColor}` : 'none',
                  color: d.status === 'pending' ? '#999' : (d.status === 'absent' || d.status === 'full' ? '#fff' : '#333'),
                  flexShrink: 0,
                }}
              >
                {d.label}
              </div>
            );
          })}
        </div>

        {/* Nút cuộn phải */}
        <Button
          shape="circle"
          size="small"
          icon={<RightOutlined />}
          onClick={handleScroll}
        />
      </div>
    </Card>
  );
}

export default TimesheetCard;
